import 'package:flutter/material.dart';

@immutable
class AppColors {
  final appgreen =const Color(0xFF378A40);

  const AppColors();
  
}